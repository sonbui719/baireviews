const API_URL = 'https://68e64f7c21dd31f22cc507d7.mockapi.io/shoes';

export const shoeService = {
  getAllShoes: async () => {
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      return { data: data.reverse(), status: res.status };
    } catch (err) {
      console.error('❌ Lỗi getAllShoes:', err);
      return { data: [], status: 500 };
    }
  },

  createShoe: async (shoe) => {
    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(shoe),
      });
      const data = await res.json();
      return { data, status: res.status };
    } catch (err) {
      console.error('❌ Lỗi createShoe:', err);
      return { data: null, status: 500 };
    }
  },

  updateShoe: async (id, shoe) => {
    try {
      const res = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(shoe),
      });
      const data = await res.json();
      return { data, status: res.status };
    } catch (err) {
      console.error('❌ Lỗi updateShoe:', err);
      return { data: null, status: 500 };
    }
  },

  deleteShoe: async (id) => {
    try {
      const res = await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
      return { status: res.status };
    } catch (err) {
      console.error('❌ Lỗi deleteShoe:', err);
      return { status: 500 };
    }
  },
};
