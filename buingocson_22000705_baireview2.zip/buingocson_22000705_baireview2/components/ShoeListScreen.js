import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, TouchableOpacity,
  StyleSheet, Alert, RefreshControl
} from 'react-native';
import { shoeService } from '../api/shoeService';

const ShoeListScreen = ({ navigation }) => {
  const [shoes, setShoes] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  // 🟢 Lấy danh sách
  const fetchShoes = async () => {
    try {
      const res = await shoeService.getAllShoes();
      if (res.status === 200) setShoes(res.data);
    } catch (err) {
      console.error('Lỗi tải danh sách:', err);
      Alert.alert('Lỗi', 'Không tải được danh sách sản phẩm');
    }
  };

  useEffect(() => { fetchShoes(); }, []);

  // 🟢 Xử lý xoá
  const handleDelete = (id, name) => {
    Alert.alert('Xác nhận', `Bạn có chắc muốn xoá "${name}"?`, [
      { text: 'Hủy', style: 'cancel' },
      {
        text: 'Xoá',
        style: 'destructive',
        onPress: async () => {
          try {
            const res = await shoeService.deleteShoe(id);
            console.log('🗑️ Xoá ID:', id, 'Kết quả:', res.status);

            if (res.status === 200 || res.status === 204) {
              Alert.alert('✅ Thành công', 'Đã xoá sản phẩm');
              fetchShoes();   // tải lại danh sách
            } else {
              Alert.alert('❗ Lỗi', `Xoá thất bại (mã ${res.status})`);
            }
          } catch (err) {
            console.error('Lỗi xoá:', err);
            Alert.alert('❗ Lỗi', 'Không thể xoá sản phẩm');
          }
        }
      }
    ]);
  };

  // 🟢 Refresh
  const onRefresh = async () => {
    setRefreshing(true);
    await fetchShoes();
    setRefreshing(false);
  };

  // 🟢 Render item
  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <View style={{ flex: 1 }}>
        <Text style={styles.code}>{item.productCode}</Text>
        <Text style={styles.name}>{item.productName}</Text>
        <Text style={styles.price}>{parseInt(item.price).toLocaleString()} ₫</Text>
        <Text>Size: {item.size}</Text>
        <Text>Số lượng: {item.quantity}</Text>
      </View>

      <View style={styles.cardActions}>
        <TouchableOpacity
          style={styles.editBtn}
          onPress={() => navigation.navigate('AddShoe', { shoe: item })}
        >
          <Text>Sửa</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.deleteBtn}
          onPress={() => handleDelete(item.id, item.productName)}
        >
          <Text style={{ color: '#fff' }}>Xoá</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <TouchableOpacity
        style={styles.addButton}
        onPress={() => navigation.navigate('AddShoe')}
      >
        <Text style={styles.addButtonText}>+ Thêm sản phẩm</Text>
      </TouchableOpacity>

      <FlatList
        data={shoes}
        keyExtractor={(i) => i.id}
        renderItem={renderItem}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  addButton: {
    backgroundColor: 'green',
    padding: 12,
    borderRadius: 4,
    alignItems: 'center',
    marginBottom: 12,
  },
  addButtonText: { color: '#fff', fontWeight: 'bold' },

  card: {
    backgroundColor: '#fff',
    padding: 12,
    marginBottom: 10,
    borderRadius: 6,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    elevation: 2,
  },
  code: { color: '#1976d2', fontWeight: '600' },
  name: { fontSize: 16, fontWeight: '500' },
  price: { color: 'green', fontWeight: '700', marginTop: 4 },

  cardActions: { flexDirection: 'row' },
  editBtn: {
    backgroundColor: 'yellow',
    padding: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  deleteBtn: { backgroundColor: 'red', padding: 8, borderRadius: 4 },
});

export default ShoeListScreen;
