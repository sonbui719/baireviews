import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, Alert
} from 'react-native';
import { shoeService } from '../api/shoeService';

const sizeOptions = ['S', 'M', 'L', 'XL', 'XXL'];

const AddShoeScreen = ({ navigation, route }) => {
  const editingShoe = route.params?.shoe || null;

  const [productCode, setProductCode] = useState(editingShoe?.productCode || '');
  const [productName, setProductName] = useState(editingShoe?.productName || '');
  const [size, setSize] = useState(editingShoe?.size || '');
  const [price, setPrice] = useState(editingShoe?.price?.toString() || '');
  const [quantity, setQuantity] = useState(editingShoe?.quantity?.toString() || '');

  const handleSave = async () => {
    if (!productCode || !productName || !size || !price || !quantity) {
      Alert.alert('Lỗi', 'Vui lòng nhập đầy đủ thông tin!');
      return;
    }

    const shoeData = {
      productCode,
      productName,
      size,
      price: Number(price),
      quantity: Number(quantity),
    };

    let res;
    if (editingShoe) {
      // update
      res = await shoeService.updateShoe(editingShoe.id, shoeData);
    } else {
      // create
      res = await shoeService.createShoe(shoeData);
    }

    if (res.status === 201 || res.status === 200) {
      Alert.alert('Thành công', editingShoe ? 'Đã cập nhật sản phẩm' : 'Đã thêm sản phẩm');
      navigation.goBack();
    } else {
      Alert.alert('Lỗi', 'Không thể lưu sản phẩm!');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        {editingShoe ? 'CẬP NHẬT SẢN PHẨM' : 'THÊM SẢN PHẨM MỚI'}
      </Text>

      <Text style={styles.label}>Mã sản phẩm</Text>
      <TextInput
        style={styles.input}
        placeholder="Nhập mã sản phẩm"
        value={productCode}
        onChangeText={setProductCode}
      />

      <Text style={styles.label}>Tên sản phẩm</Text>
      <TextInput
        style={styles.input}
        placeholder="Nhập tên sản phẩm"
        value={productName}
        onChangeText={setProductName}
      />

      <Text style={styles.label}>Chọn size</Text>
      <View style={styles.sizeRow}>
        {sizeOptions.map(s => (
          <TouchableOpacity
            key={s}
            style={[styles.sizeBtn, size === s && styles.sizeSelected]}
            onPress={() => setSize(s)}
          >
            <Text style={[styles.sizeText, size === s && styles.sizeTextSelected]}>
              {s}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>Giá (VND)</Text>
      <TextInput
        style={styles.input}
        placeholder="Nhập giá sản phẩm"
        keyboardType="numeric"
        value={price}
        onChangeText={setPrice}
      />

      <Text style={styles.label}>Số lượng</Text>
      <TextInput
        style={styles.input}
        placeholder="Nhập số lượng"
        keyboardType="numeric"
        value={quantity}
        onChangeText={setQuantity}
      />

      <TouchableOpacity style={styles.addButton} onPress={handleSave}>
        <Text style={styles.addButtonText}>
          {editingShoe ? 'CẬP NHẬT' : 'THÊM SẢN PHẨM'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default AddShoeScreen;

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#4A56E2',
  },
  label: { fontSize: 14, fontWeight: '500', marginTop: 12 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    padding: 10,
    marginTop: 4,
  },
  sizeRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 8 },
  sizeBtn: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    flex: 1,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  sizeSelected: { backgroundColor: '#4A56E2', borderColor: '#4A56E2' },
  sizeText: { fontSize: 14 },
  sizeTextSelected: { color: '#fff', fontWeight: '600' },
  addButton: {
    backgroundColor: 'green',
    padding: 14,
    borderRadius: 6,
    marginTop: 20,
    alignItems: 'center',
  },
  addButtonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
});
