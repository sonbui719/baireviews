import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import ShoeListScreen from './components/ShoeListScreen';
import AddShoeScreen from './components/AddShoeScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="ShoeList" component={ShoeListScreen} options={{ title: 'Danh sách giày' }} />
        <Stack.Screen name="AddShoe" component={AddShoeScreen} options={{ title: 'Thêm / Sửa giày' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
